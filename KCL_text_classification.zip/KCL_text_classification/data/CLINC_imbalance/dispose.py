import pandas as pd

f = pd.read_csv('./test.csv',sep=',')
f.to_csv('./test.tsv',sep='\t',index=False)
