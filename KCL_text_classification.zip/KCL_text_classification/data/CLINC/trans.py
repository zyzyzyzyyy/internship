import pandas as pd
df = pd.read_csv('train.csv')
df.to_csv('train.tsv',sep='\t',index=False)
