
import torch
from torch import nn
import numpy as np
from torch.nn import init
from transformers import AutoModel,BertModel, RobertaModel, BertPreTrainedModel
from transformers.modeling_outputs import SequenceClassifierOutput
from transformers.models.bert import BertForSequenceClassification
from transformers.models.roberta import RobertaForSequenceClassification
from transformers.models.roberta.modeling_roberta import RobertaPreTrainedModel
from torch.nn import CrossEntropyLoss, MSELoss

#remote_sever
def l2norm(x: torch.Tensor):
    norm = torch.pow(x, 2).sum(dim=-1, keepdim=True).sqrt()
    x = torch.div(x, norm)
    return x

import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer

def pair_cosine_similarity(x, x_adv, eps=1e-8):
    n = x.norm(p=2, dim=1, keepdim=True)
    n_adv = x_adv.norm(p=2, dim=1, keepdim=True)

    return (x @ x.t()) / (n * n.t()).clamp(min=eps), (x_adv @ x_adv.t()) / (n_adv * n_adv.t()).clamp(min=eps), (
                x @ x_adv.t()) / (n * n_adv.t()).clamp(min=eps)


def nx_xent(x, x_adv, mask, cuda=True, t=0.5):
    x, x_adv, x_c = pair_cosine_similarity(x, x_adv)
    x = torch.exp(x / t)
    x_adv = torch.exp(x_adv / t)
    x_c = torch.exp(x_c / t)
    mask_count = mask.sum(1)
    mask_reverse = (~(mask.bool())).long()
    if cuda:
        dis = (x * (mask - torch.eye(x.size(0)).long().cuda()) + x_c * mask) / (
                    x.sum(1) + x_c.sum(1) - torch.exp(torch.tensor(1 / t))) + mask_reverse
        dis_adv = (x_adv * (mask - torch.eye(x.size(0)).long().cuda()) + x_c.T * mask) / (
                    x_adv.sum(1) + x_c.sum(0) - torch.exp(torch.tensor(1 / t))) + mask_reverse
    else:
        dis = (x * (mask - torch.eye(x.size(0)).long()) + x_c * mask) / (
                    x.sum(1) + x_c.sum(1) - torch.exp(torch.tensor(1 / t))) + mask_reverse
        dis_adv = (x_adv * (mask - torch.eye(x.size(0)).long()) + x_c.T * mask) / (
                    x_adv.sum(1) + x_c.sum(0) - torch.exp(torch.tensor(1 / t))) + mask_reverse
    loss = (torch.log(dis).sum(1) + torch.log(dis_adv).sum(1)) / mask_count
    return -loss.mean()


class RobertaClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.num_labels)

    def forward(self, features, **kwargs):
        # x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        x = self.dropout(features)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x


class RobertaClassification(nn.Module):

    def __init__(self, config):
        super(RobertaClassification, self).__init__()
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.num_labels)

    def forward(self, features, **kwargs):
        x = self.dropout(features)
        x = self.out_proj(x)
        return x


class BertClassificationHead(nn.Module):
    def __init__(self, config):
        super(BertClassificationHead, self).__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.num_labels)
        
    def forward(self, feature):
        x = self.dropout(feature)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x

    
class BertContrastiveHead(nn.Module):
    def __init__(self, config):
        super(BertContrastiveHead, self).__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.hidden_size)

    def forward(self, feature):
        x = self.dropout(feature)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x


class RobertaContrastiveHead(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.hidden_size)

    def forward(self, features, **kwargs):
        # x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        x = self.dropout(features)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x

class BaseBert(nn.Module):
    def __init__(self, config):
        super(BaseBert, self).__init__()
        self.config = config
        self.number_labels = config.num_labels
        if config.load_trained_model: # False
            self.encoder_q = AutoModel(config)
        else:
            self.encoder_q = BertModel.from_pretrained(config.model_name, config=config)

        self.classifier_liner = BertClassificationHead(config)

        self.train_multi_head = config.train_multi_head #False
        self.multi_head_num = config.multi_head_num #32
        
        params_to_train = ["layer." + str(i) for i in range(0,12)]
        for name, param in self.encoder_q.named_parameters():
            
            param.requires_grad_(False)
            for term in params_to_train:
                if term in name:
                    param.requires_grad_(True)

    def forward_no_multi_v2(self,
                            query,
                            ):
        labels = query["labels"]
        labels = labels.view(-1)
        query.pop('labels')
        query.pop('original_text')
        query.pop('sent_id')
        
        bert_output_q = self.encoder_q(**query)
        q = bert_output_q[1]
        logits_cls = self.classifier_liner(q)
        loss_fct = CrossEntropyLoss()
        if torch.cuda.is_available():
            loss_fct = loss_fct.cuda()
        loss = loss_fct(logits_cls.view(-1, self.number_labels), labels)

        return SequenceClassifierOutput(
            loss=loss,
        )

    def forward(self,
                query,# batch_size * max_length
                mode,
                ):
        #query.keys(['original_text', 'labels', 'input_ids', 'token_type_ids', 'attention_mask', 'sent_id'])
        if mode == 'train':
            return self.forward_no_multi_v2(query=query)
        elif mode == 'validation':
            labels = query['labels']
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            logits_cls = self.classifier_liner(seq_embed)
            probs = torch.softmax(logits_cls, dim=1)
            
            return torch.argmax(probs, dim=1).tolist(), labels.cpu().numpy().tolist()
            
        elif mode == 'test':
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            logits_cls = self.classifier_liner(seq_embed)
            probs = torch.softmax(logits_cls, dim=1)
            
            return torch.argmax(probs, dim=1).tolist(), labels.cpu().numpy().tolist()
        else:
            raise ValueError("undefined mode")

    # eval
    def predict(self, query):
        with torch.no_grad():
            bert_output_q = self.encoder_q(**query)
            q = bert_output_q[1]
            logits_cls = self.classifier_liner(q)
        return logits_cls
    
#@torch.no_grad()
#def distributed_sinkhorn(out, config):
    #Q = torch.exp(out / 0.05).t()
    #B = Q.shape[1]  # number of samples to assign
    #K = Q.shape[0]  # how many prototypes

    # make the matrix sums to 1
    #sum_Q = torch.sum(Q)
    #Q /= sum_Q

    #for it in range(3):
    # normalize each row: total weight per prototype must be 1/K
        #sum_of_rows = torch.sum(Q, dim=1, keepdim=True)
        #Q /= sum_of_rows
        #Q /= K

    # normalize each column: total weight per sample must be 1/B
        #Q /= torch.sum(Q, dim=0, keepdim=True)
        #Q /= B
        
    #Q *= B  # the colomns must sum to 1 so that Q is an assignment
    #return Q.t()

class ContrastiveMoCoKnnBert(nn.Module):

    def __init__(self, config):
        super(ContrastiveMoCoKnnBert, self).__init__()
        self.config = config
        # 修改config的dropout系数
        config.attention_probs_dropout_prob = config.dropout_prob
        config.hidden_dropout_prob = config.dropout_prob

        self.number_labels = config.num_labels
        self.encoder_q = AutoModel.from_pretrained(config.model_name, config=config)
        self.encoder_k = AutoModel.from_pretrained(config.model_name, config=config)

        self.classifier_liner = BertClassificationHead(config)

        self.contrastive_liner_q = BertContrastiveHead(config)
        self.contrastive_liner_k = BertContrastiveHead(config)
        self.m = config.m
        self.T = config.T
        self.train_multi_head = config.train_multi_head #False
        self.multi_head_num = config.multi_head_num #32
        self.update_num = 3

        if not config.load_trained_model:
            self.init_weights() # Exec

        # create the label_queue and feature_queue
        self.K = config.queue_size # 7500

        self.register_buffer("label_queue", torch.randint(-1, 0, [self.K])) # Tensor:(7500,)
        self.register_buffer("feature_queue", torch.randn(self.K, config.hidden_size)) # Tensor:(7500, 768)
        self.feature_queue = torch.nn.functional.normalize(self.feature_queue, dim=0)

        self.register_buffer("queue_ptr", torch.zeros(1, dtype=torch.long)) # Tensor(1,)
        self.top_k = config.knn_num # 25

        # optional and delete can improve the performance indicated 
        # by some experiment
        params_to_train = ["layer." + str(i) for i in range(0,12)]
        for name, param in self.encoder_q.named_parameters():
            param.requires_grad_(False)
            for term in params_to_train:
                if term in name:
                    param.requires_grad_(True)


    def _dequeue_and_enqueue(self, keys, label):
        batch_size = keys.shape[0]

        ptr = int(self.queue_ptr)

        if ptr + batch_size > self.K:
            batch_size = self.K - ptr
            keys = keys[: batch_size]
            label = label[: batch_size]

        # replace the keys at ptr (dequeue ans enqueue)
        self.feature_queue[ptr: ptr + batch_size, :] = keys
        self.label_queue[ptr: ptr + batch_size] = label
        
        ptr = (ptr + batch_size) % self.K
        self.queue_ptr[0] = ptr

    def select_sample(self, liner_q: torch.Tensor, label_q: torch.Tensor):
        label_queue = self.label_queue.clone().detach()  # K
        feature_queue = self.feature_queue.clone().detach()  # K * hidden_size

        # 1. expand label_queue and feature_queue to batch_size * K
        batch_size = label_q.shape[0]
        tmp_label_queue = label_queue.repeat([batch_size, 1])
        tmp_feature_queue = feature_queue.unsqueeze(0)
        tmp_feature_queue = tmp_feature_queue.repeat([batch_size, 1, 1])  # batch_size * K * hidden_size
        # 2.caluate sim
        cos_sim = torch.einsum('nc,nkc->nk', [liner_q, tmp_feature_queue])
        # 用限制最邻近样本大方式限制相同标签的范围
        #local_place = 65
        #top_sample, sample_index = cos_sim.topk(local_place, dim=-1)
        #top_label = torch.gather(tmp_label_queue, 1, sample_index)
        # 用卡阈值的方式限制相同标签的范围
        shreshold_place = torch.gt(cos_sim, self.config.scope)
        #feature_value = cos_sim.masked_select(shreshold_place)
        label_value = tmp_label_queue.masked_select(shreshold_place)
        #top_sample = torch.full_like(cos_sim, -np.inf).cuda()
        #top_sample = top_sample.masked_scatter(shreshold_place, feature_value)
        top_label = torch.full_like(tmp_label_queue, -1).cuda()
        top_label = top_label.masked_scatter(shreshold_place, label_value)
        #print(topk_sample_index)
        # 3. get index of postive and neigative
        # 标签相同为positive，不同为neigative
        tmp_label = label_q.unsqueeze(1)
        tmp_label = tmp_label.repeat([1, self.K])
        tmp_mask_index = torch.eq(tmp_label_queue, tmp_label)
        neg_mask_index = ~ tmp_mask_index

        tmp_label2 = label_q.unsqueeze(1)
        tmp_label2 = tmp_label2.repeat([1, self.K])
        #tmp_label2 = tmp_label2.repeat([1, local_place])
        pos_mask_index = torch.eq(top_label, tmp_label2)

        # 4.select the positive and neigative samples
        feature_value = cos_sim.masked_select(neg_mask_index)
        neg_sample = torch.full_like(cos_sim, -np.inf).cuda()
        neg_sample = neg_sample.masked_scatter(neg_mask_index, feature_value)

        feature_value = cos_sim.masked_select(pos_mask_index)
        pos_sample = torch.full_like(cos_sim, 0).cuda()
        pos_sample = pos_sample.masked_scatter(pos_mask_index, feature_value)
        
        #feature_value = top_sample.masked_select(pos_mask_index)
        #pos_sample = torch.full_like(top_sample, -np.inf).cuda()
        #pos_sample = pos_sample.masked_scatter(pos_mask_index, feature_value)

        # 5.k-nearest samples which have the same label with q
        one_mask_index = pos_mask_index.int()
        one_number = one_mask_index.sum(dim=-1)
        one_min = one_number.min()
        if one_min == 0:
            return None
        one_sample = pos_sample.mean(dim=-1, keepdim=True)
        # 7.neigative samples
        neg_mask_index = neg_mask_index.int()
        neg_number = neg_mask_index.sum(dim=-1)
        neg_min = neg_number.min()
        if neg_min == 0:
            return None
        neg_sample, _ = neg_sample.topk(neg_min, dim=-1)
        # 8.calculate and return
        logits_con = torch.cat([one_sample, neg_sample], dim=-1)
        logits_con /= self.T
        return logits_con

    def init_weights(self):
        for param_q, param_k in zip(self.contrastive_liner_q.parameters(), self.contrastive_liner_k.parameters()):
            param_k.data = param_q.data

    def update_encoder_k(self):
        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)
        for param_q, param_k in zip(self.contrastive_liner_q.parameters(), self.contrastive_liner_k.parameters()):
            param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)

    def reshape_dict(self, batch):
        for k, v in batch.items():
            shape = v.shape
            batch[k] = v.view([-1, shape[-1]])
        return batch
    
    def forward_no_multi_v2(self,
                            query,
                            ):
        labels = query["labels"]
        labels = labels.view(-1)
        query.pop('labels')
        query.pop('original_text')
        query.pop('sent_id')

        #Moco样本队列使用的bert，不能利用梯度更新参数
        with torch.no_grad():
            self.update_encoder_k()
            update_sample = self.reshape_dict(query)
            bert_output_p = self.encoder_k(**update_sample)
            update_keys = bert_output_p[1]
            #logits_cls2 = self.classifier_liner(update_keys)
            update_keys = self.contrastive_liner_q(update_keys)
            update_keys = l2norm(update_keys)
            self._dequeue_and_enqueue(update_keys, labels)

        bert_output_q = self.encoder_q(**query)
        q = bert_output_q[1]
        liner_q = self.contrastive_liner_q(q)
        liner_q = l2norm(liner_q)
        #liner_q = l2norm(q)
        logits_cls = self.classifier_liner(q)

        loss_fct = CrossEntropyLoss()
        if torch.cuda.is_available():
            loss_fct = loss_fct.cuda()

        loss_cls = loss_fct(logits_cls.view(-1, self.number_labels), labels)
        logits_con = self.select_sample(liner_q, labels)
        #self._dequeue_and_enqueue(update_keys, labels)

        if logits_con is not None:
            labels_con = torch.zeros(logits_con.shape[0], dtype=torch.long).cuda()
            loss_fct = CrossEntropyLoss()
            if torch.cuda.is_available():
                loss_fct = loss_fct.cuda()
            loss_con = loss_fct(logits_con, labels_con)
           
            loss = loss_con * self.config.contrastive_rate_in_training + \
                   loss_cls 
        else:
            loss = loss_cls
        return SequenceClassifierOutput(
            loss=loss,
        )

    def forward(self,
                query,# batch_size * max_length
                mode,
                ):
        #query.keys(['original_text', 'labels', 'input_ids', 'token_type_ids', 'attention_mask', 'sent_id'])
        if mode == 'train':
            return self.forward_no_multi_v2(query=query)
        elif mode == 'test':
            labels = query['labels']
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            logits_cls = self.classifier_liner(seq_embed)
            probs = torch.softmax(logits_cls, dim=1)
                        
            return torch.argmax(probs, dim=1).tolist(), labels.cpu().numpy().tolist()
            
        elif mode == 'validation':
            labels = query['labels']
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            logits_cls = self.classifier_liner(seq_embed)
            probs = torch.softmax(logits_cls, dim=1)
            
            max_probs = torch.max(probs, dim=1)
            check_sample = torch.full_like(max_probs.values, self.config.threshold_other).cuda()
            other_index = torch.gt(check_sample, max_probs.values)
            results = torch.argmax(probs, dim=1)
            other_sample = torch.full_like(results, -1).cuda()
            results = results.masked_scatter(other_index, other_sample)
            return results.tolist(), labels.cpu().numpy().tolist()
        else:
            raise ValueError("undefined mode")
    # eval
    def predict(self, query):
        with torch.no_grad():
            bert_output_q = self.encoder_q(**query)
            q = bert_output_q[1]
            logits_cls = self.classifier_liner(q)
            contrastive_output = self.contrastive_liner_q(q)
        return contrastive_output, logits_cls
