CUDA_VISIBLE_DEVICES=0,1 python run_main.py knn_bert.json
