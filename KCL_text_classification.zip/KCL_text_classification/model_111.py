import torch
from torch import nn
import numpy as np
from torch.nn import init
from transformers import BertModel, RobertaModel, BertPreTrainedModel
from transformers.modeling_outputs import SequenceClassifierOutput
from transformers.models.bert import BertForSequenceClassification
from transformers.models.roberta import RobertaForSequenceClassification
from transformers.models.roberta.modeling_roberta import RobertaPreTrainedModel
from torch.nn import CrossEntropyLoss, MSELoss
import copy

#remote_sever
def l2norm(x: torch.Tensor):
    norm = torch.pow(x, 2).sum(dim=-1, keepdim=True).sqrt()
    x = torch.div(x, norm)
    return x

import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer

def pair_cosine_similarity(x, x_adv, eps=1e-8):
    n = x.norm(p=2, dim=1, keepdim=True)
    n_adv = x_adv.norm(p=2, dim=1, keepdim=True)

    return (x @ x.t()) / (n * n.t()).clamp(min=eps), (x_adv @ x_adv.t()) / (n_adv * n_adv.t()).clamp(min=eps), (
                x @ x_adv.t()) / (n * n_adv.t()).clamp(min=eps)


def nx_xent(x, x_adv, mask, cuda=True, t=0.5):
    x, x_adv, x_c = pair_cosine_similarity(x, x_adv)
    x = torch.exp(x / t)
    x_adv = torch.exp(x_adv / t)
    x_c = torch.exp(x_c / t)
    mask_count = mask.sum(1)
    mask_reverse = (~(mask.bool())).long()
    if cuda:
        dis = (x * (mask - torch.eye(x.size(0)).long().cuda()) + x_c * mask) / (
                    x.sum(1) + x_c.sum(1) - torch.exp(torch.tensor(1 / t))) + mask_reverse
        dis_adv = (x_adv * (mask - torch.eye(x.size(0)).long().cuda()) + x_c.T * mask) / (
                    x_adv.sum(1) + x_c.sum(0) - torch.exp(torch.tensor(1 / t))) + mask_reverse
    else:
        dis = (x * (mask - torch.eye(x.size(0)).long()) + x_c * mask) / (
                    x.sum(1) + x_c.sum(1) - torch.exp(torch.tensor(1 / t))) + mask_reverse
        dis_adv = (x_adv * (mask - torch.eye(x.size(0)).long()) + x_c.T * mask) / (
                    x_adv.sum(1) + x_c.sum(0) - torch.exp(torch.tensor(1 / t))) + mask_reverse
    loss = (torch.log(dis).sum(1) + torch.log(dis_adv).sum(1)) / mask_count
    return -loss.mean()


class RobertaClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.num_labels)

    def forward(self, features, **kwargs):
        # x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        x = self.dropout(features)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x


class RobertaClassification(nn.Module):

    def __init__(self, config):
        super(RobertaClassification, self).__init__()
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.num_labels)

    def forward(self, features, **kwargs):
        x = self.dropout(features)
        x = self.out_proj(x)
        return x


class BertClassificationHead(nn.Module):
    def __init__(self, config):
        super(BertClassificationHead, self).__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.num_labels)
        
    def forward(self, feature):
        x = self.dropout(feature)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x


        
        

    
        

    
class BertContrastiveHead(nn.Module):
    def __init__(self, config):
        super(BertContrastiveHead, self).__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.hidden_size)

    def forward(self, feature):
        x = self.dropout(feature)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x


class RobertaContrastiveHead(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, config.hidden_size)

    def forward(self, features, **kwargs):
        # x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        x = self.dropout(features)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x

class BaseBert(nn.Module):
    def __init__(self, config):
        super(BaseBert, self).__init__()
        self.config = config
        self.number_labels = config.num_labels
        if config.load_trained_model: # False
            self.encoder_q = BertModel(config)
        else:
            self.encoder_q = BertModel.from_pretrained(config.model_name, config=config)

        self.classifier_liner = BertClassificationHead(config)

        self.train_multi_head = config.train_multi_head #False
        self.multi_head_num = config.multi_head_num #32
        
        params_to_train = ["layer." + str(i) for i in range(0,12)]
        for name, param in self.encoder_q.named_parameters():
            param.requires_grad_(False)
            for term in params_to_train:
                if term in name:
                    param.requires_grad_(True)
        
    def forward_no_multi_v2(self,
                            query,
                            ):
        labels = query["labels"]
        labels = labels.view(-1)
        query.pop('labels')
        query.pop('original_text')
        query.pop('sent_id')
        
        bert_output_q = self.encoder_q(**query)
        q = bert_output_q[1]
        logits_cls = self.classifier_liner(q)
        loss_fct = CrossEntropyLoss()
        if torch.cuda.is_available():
            loss_fct = loss_fct.cuda()
        loss = loss_fct(logits_cls.view(-1, self.number_labels), labels)

        return SequenceClassifierOutput(
            loss=loss,
        )

    def forward(self,
                query,# batch_size * max_length
                mode,
                ):
        #query.keys(['original_text', 'labels', 'input_ids', 'token_type_ids', 'attention_mask', 'sent_id'])
        if mode == 'train':
            return self.forward_no_multi_v2(query=query)
        elif mode == 'validation':
            labels = query['labels']
            #labels_one_hot = nn.functional.one_hot(labels, self.number_labels - 1).float()
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            logits_cls = self.classifier_liner(seq_embed)
            probs = torch.softmax(logits_cls, dim=1)
            
            return torch.argmax(probs, dim=1).tolist(), labels.cpu().numpy().tolist()
            
        elif mode == 'test':
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            logits_cls = self.classifier_liner(seq_embed)
            probs = torch.softmax(logits_cls, dim=1)
            
            return torch.argmax(probs, dim=1).tolist(), labels.cpu().numpy().tolist()
        else:
            raise ValueError("undefined mode")

    # eval
    def predict(self, query):
        with torch.no_grad():
            bert_output_q = self.encoder_q(**query)
            q = bert_output_q[1]
            logits_cls = self.classifier_liner(q)
        return logits_cls
    
        
class ContrastiveMoCoKnnBert(nn.Module):

    def __init__(self, config):
        super(ContrastiveMoCoKnnBert, self).__init__()
        self.config = config
        self.number_labels = config.num_labels
        if config.load_trained_model: # False
            self.encoder_q = BertModel(config)
            self.encoder_k = BertModel(config)
        else:
            self.encoder_q = BertModel.from_pretrained(config.model_name, config=config)
            self.encoder_k = BertModel.from_pretrained(config.model_name, config=config)

        self.classifier_liner = BertClassificationHead(config)

        self.contrastive_liner_q = BertContrastiveHead(config)
        self.contrastive_liner_k = BertContrastiveHead(config)

        self.m = 0.999
        self.T = config.T
        self.train_multi_head = config.train_multi_head #False
        self.multi_head_num = config.multi_head_num #32
        self.update_num = 3

        #if not config.load_trained_model:
            #self.init_weights() # Exec

        # create the label_queue and feature_queue
        self.K = config.queue_size # 7500

        self.register_buffer("label_queue", torch.randint(0, self.number_labels, [self.K])) # Tensor:(7500,)
        self.register_buffer("feature_queue", torch.randn(self.K, config.hidden_size)) # Tensor:(7500, 768)
        self.feature_queue = torch.nn.functional.normalize(self.feature_queue, dim=0)

        self.register_buffer("queue_ptr", torch.zeros(1, dtype=torch.long)) # Tensor(1,)
        self.top_k = config.knn_num # 25

        # optional and delete can improve the performance indicated 
        # by some experiment
        params_to_train = ["layer." + str(i) for i in range(0,12)]
        for name, param in self.encoder_q.named_parameters():
            param.requires_grad_(False)
            for term in params_to_train:
                if term in name:
                    param.requires_grad_(True)


    def _dequeue_and_enqueue(self, keys, label):
        batch_size = keys.shape[0]

        ptr = int(self.queue_ptr)
        temp_size = 0

        if ptr + batch_size > self.K:
            temp_size = batch_size - self.K + ptr
            batch_size = self.K - ptr

            keys1 = copy.deepcopy(keys[batch_size:])
            label1 = copy.deepcopy(label[batch_size:])
            keys = copy.deepcopy(keys[: batch_size])
            label = copy.deepcopy(label[: batch_size])

            self.feature_queue[0: temp_size, :] = keys1
            self.label_queue[0: temp_size] = label1

        # replace the keys at ptr (dequeue ans enqueue)
        self.feature_queue[ptr: ptr + batch_size, :] = keys
        self.label_queue[ptr: ptr + batch_size] = label

        ptr = (ptr + batch_size + temp_size) % self.K

        self.queue_ptr[0] = ptr

    def select_sample(self, liner_q: torch.Tensor, label_q: torch.Tensor):
        label_queue = self.label_queue.clone().detach()        # K
        feature_queue = self.feature_queue.clone().detach()    # K * hidden_size
        
        # 1. expand label_queue and feature_queue to batch_size * K
        batch_size = label_q.shape[0]
        tmp_label_queue = label_queue.repeat([batch_size, 1])
        tmp_feature_queue = feature_queue.unsqueeze(0)
        tmp_feature_queue = tmp_feature_queue.repeat([batch_size, 1, 1]) # batch_size * K * hidden_size
        # 2.caluate sim
        cos_sim = torch.einsum('nc,nkc->nk', [liner_q, tmp_feature_queue])
        
        # 3. get index of postive and neigative 
        #标签相同为positive，不同为neigative
        tmp_label = label_q.unsqueeze(1)
        tmp_label = tmp_label.repeat([1, self.K])
        pos_mask_index = torch.eq(tmp_label_queue, tmp_label)
        neg_mask_index = ~ pos_mask_index
        
        # 4.select the positive and neigative samples
        feature_value = cos_sim.masked_select(neg_mask_index)
        neg_sample = torch.full_like(cos_sim, -np.inf).cuda()
        neg_sample = neg_sample.masked_scatter(neg_mask_index, feature_value)
        
        feature_value = cos_sim.masked_select(pos_mask_index)
        pos_sample = torch.full_like(cos_sim, -np.inf).cuda()
        pos_sample = pos_sample.masked_scatter(pos_mask_index, feature_value)
        
        #5.k-nearest samples which have the same label with q
        one_mask_index = pos_mask_index.int()
        one_number = one_mask_index.sum(dim=-1)
        one_min = one_number.min()
        if one_min == 0:
            return None
        #one_sample, _ = cos_sim.topk(one_min, dim=-1)
        one_sample, _ = pos_sample.topk(one_min, dim=-1)
        num_min = min(self.top_k, one_min)
        one_sample_top_k = one_sample[:, 0:num_min] # self.topk = 25

        one_sample = one_sample_top_k
        one_sample = one_sample.contiguous().view([-1, 1])

        #7.neigative samples
        neg_mask_index = neg_mask_index.int()
        neg_number = neg_mask_index.sum(dim=-1)
        neg_min = neg_number.min()
        if neg_min == 0:
            return None



        neg_sample, _ = neg_sample.topk(neg_min, dim=-1)
        neg_topk = min(one_min, self.top_k)
    
        neg_sample = neg_sample.repeat([1, neg_topk])
        neg_sample = neg_sample.view([-1, neg_min])
        
        #8.calculate and return
        logits_con = torch.cat([one_sample, neg_sample], dim=-1)
        #logits_same = torch.cat([one_sample, pos_sample], dim=-1)
        logits_con /= self.T
        #logits_same /= self.T
        return logits_con


    #def init_weights(self):
        #for param_q, param_k in zip(self.contrastive_liner_q.parameters(), self.contrastive_liner_k.parameters()):
            #param_k.data = param_q.data

    def update_encoder_k(self):
        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)
        for param_q, param_k in zip(self.contrastive_liner_q.parameters(), self.contrastive_liner_k.parameters()):
            param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)

    def reshape_dict(self, batch):
        for k, v in batch.items():
            shape = v.shape
            batch[k] = v.view([-1, shape[-1]])
        return batch
    
    def forward_no_multi_v2(self,
                            query,
                            ):
        query_record = query
        labels = query["labels"]
        labels = labels.view(-1)
        query.pop('labels')
        query.pop('original_text')
        query.pop('sent_id')
        
        #Moco样本队列使用的bert，不能利用梯度更新参数
        with torch.no_grad():
            self.update_encoder_k()
            update_sample = self.reshape_dict(query)
            bert_output_p = self.encoder_k(**update_sample)
            update_keys = bert_output_p[1]
            update_keys = self.contrastive_liner_k(update_keys)
            update_keys = l2norm(update_keys)

        bert_output_q = self.encoder_q(**query)
        q = bert_output_q[1]
        liner_q = self.contrastive_liner_q(q)
        liner_q = l2norm(liner_q)
        logits_cls = self.classifier_liner(q)


        loss_fct = CrossEntropyLoss()
        if torch.cuda.is_available():
            loss_fct = loss_fct.cuda()

        loss_cls = loss_fct(logits_cls.view(-1, self.number_labels), labels)
        logits_con = self.select_sample(update_keys, labels)
        self._dequeue_and_enqueue(update_keys, labels)
            
        if logits_con is not None:
            labels_con = torch.zeros(logits_con.shape[0], dtype=torch.long).cuda()
            loss_fct = CrossEntropyLoss()
            if torch.cuda.is_available():
                loss_fct = loss_fct.cuda()
            loss_con = loss_fct(logits_con, labels_con)
           
            loss = loss_con * self.config.contrastive_rate_in_training + \
                   loss_cls * (1 - self.config.contrastive_rate_in_training)
        else:
            loss = loss_cls
        return SequenceClassifierOutput(
            loss=loss,
        )

    def forward(self,
                query,# batch_size * max_length
                mode,
                ):
        #query.keys(['original_text', 'labels', 'input_ids', 'token_type_ids', 'attention_mask', 'sent_id'])
        if mode == 'train':
            return self.forward_no_multi_v2(query=query)
        elif mode == 'validation':
            labels = query['labels']
            #labels_one_hot = nn.functional.one_hot(labels, self.number_labels - 1).float()
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            #seq_embed = self.contrastive_liner_q(seq_embed)
            logits_cls = self.classifier_liner(seq_embed)
            probs = torch.softmax(logits_cls, dim=1)
            
            return torch.argmax(probs, dim=1).tolist(), labels.cpu().numpy().tolist()
            
        elif mode == 'test':
            labels = query['labels']
            query.pop('labels')
            query.pop('original_text')
            query.pop('sent_id')
            
            seq_embed = self.encoder_q(**query)[1]
            #seq_embed = self.contrastive_liner_q(seq_embed)
            logits_cls = self.classifier_liner(seq_embed)
            
            probs = torch.softmax(logits_cls, dim=1)
            
            return torch.argmax(probs, dim=1).tolist(), labels.cpu().numpy().tolist()
        else:
            raise ValueError("undefined mode")
    # eval
    def predict(self, query):
        with torch.no_grad():
            bert_output_q = self.encoder_q(**query)
            q = bert_output_q[1]
            #q = self.contrastive_liner_q(q)
            logits_cls = self.classifier_liner(q)
            contrastive_output = self.contrastive_liner_q(q)
        return contrastive_output, logits_cls




