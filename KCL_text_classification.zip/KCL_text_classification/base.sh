UDA_VISIBLE_DEVICES=$2 python run_main.py jsons/base_bert.json

