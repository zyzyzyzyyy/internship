import tensorflow as tf
r1 = tf.Variable(tf.constant([[1,1],[1,1]]))
r2 = tf.Variable(tf.constant([[0,0],[0,0],[0,0]]))
r3 = tf.einsum('ij,kj->ik', r1, r2)
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    print(sess.run(r3))
