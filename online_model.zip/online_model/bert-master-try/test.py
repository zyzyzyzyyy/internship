import tensorflow as tf
r1 = tf.Variable(tf.constant(1))
r2 = tf.Variable(tf.constant(2))

with tf.control_dependencies([r2]):
    r3 = tf.add(r1, r2)

r_sum = tf.add(r1,r3)
r1 = tf.add(r_sum, r1)
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    print(sess.run(r1))
