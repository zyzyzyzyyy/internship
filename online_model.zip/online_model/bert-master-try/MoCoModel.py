#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import numpy as np
import os
import subprocess
import tensorflow as tf

class ContrastiveHead(object):
    def __init__(self,
                 feature_dim,
                 head_number):
        self.output_weights1 = tf.get_variable(
            "output_weights1_"+head_number, [feature_dim,feature_dim],
            initializer=tf.truncated_normal_initializer(stddev=0.02))

        self.output_bias1 = tf.get_variable(
            "output_bias1_"+head_number, [feature_dim], initializer=tf.zeros_initializer())

        self.output_weights2 = tf.get_variable(
            "output_weights2_"+head_number, [feature_dim, feature_dim],
            initializer=tf.truncated_normal_initializer(stddev=0.02))

        self.output_bias2 = tf.get_variable(
            "output_bias2_"+head_number, [feature_dim], initializer=tf.zeros_initializer())\
    
    def get_forward(self, bert_output):
        output_layer = tf.nn.dropout(bert_output, keep_prob=0.9)
        output_layer = tf.matmul(output_layer, self.output_weights1, transpose_b=True)
        output_layer = tf.nn.bias_add(output_layer, self.output_bias1)
        output_layer = tf.nn.tanh(output_layer)
        output_layer = tf.nn.dropout(output_layer, keep_prob=0.9)
        output_layer = tf.matmul(output_layer, self.output_weights2, transpose_b=True)
        output_layer = tf.nn.bias_add(output_layer, self.output_bias2)
        return output_layer

class ContrastiveModel(object):
    def __init__(self,
                 config,
                 hidden_size):
        self.feature_dim = hidden_size
        # NOTE: implicit assume queue_size % (batch_size * GPU) ==0
        self.queue_size = 65536
    
    def get_loss(self, q_feat, key_feat, labels):
        input_shape = q_feat.shape.as_list()
        self.batch_size = input_shape[0]
        labels = tf.cast(labels, tf.int32)
        # setup queue
        queue_init = tf.math.l2_normalize(
            tf.random.normal([self.queue_size, self.feature_dim]), axis=1)
        queue = tf.get_variable('queue', initializer=queue_init, trainable=False)
        queue_init_label = tf.fill([self.queue_size], -1)
        label_queue = tf.get_variable('label_queue', initializer=queue_init_label, trainable=False)
        queue_ptr = tf.get_variable(
            'queue_ptr',
            [], initializer=tf.zeros_initializer(),
            dtype=tf.int64, trainable=False)
        
        #update queue
        update_ops = self.push_queue(queue, label_queue, queue_ptr, key_feat, labels)
        
        with tf.control_dependencies([update_ops]):
            #distance
            l_queue = tf.einsum('nc,kc->nk', q_feat, queue)  # nxK
            
            #limit the space of samples with same label by seting threshold 
            shreshold = tf.fill(l_queue.shape, 0.47)
            shreshold_space = tf.greater(l_queue, shreshold)
        
            #change all the labels of samples which are not in the threshold space to -1
            select_label = tf.reshape(label_queue, [1,-1])
            select_label = tf.repeat(select_label, repeats=self.batch_size, axis=0)
            bad_label = tf.fill(select_label.shape, -1)
            top_label = tf.where(shreshold_space, select_label, bad_label, name='top_label')
        
            #find positive sample
            query_label = tf.reshape(labels, [-1,1])
            query_label = tf.repeat(query_label, repeats=self.queue_size, axis=1)
            pos_sample_index = tf.equal(query_label, top_label)

            one_sample_index = tf.cast(pos_sample_index, dtype=tf.int32)
            one_number = tf.reduce_sum(one_sample_index, axis=1)
            one_min = tf.reduce_min(one_number, axis=0)
            
            #calculate the center 
            one_number = tf.cast(tf.reshape(one_number, [-1,1]), dtype=tf.float32)
            tmp_sample = tf.zeros_like(l_queue, dtype=tf.float32)
            pos_sample = tf.where(pos_sample_index, l_queue, tmp_sample, name='pos_sample')
            pos_sample = tf.reduce_sum(pos_sample, axis=1, keepdims=True)
                
            tmp_one = tf.zeros(one_min.shape, dtype=tf.int32)
            one_sample = tf.cond(
                tf.equal(one_min, tmp_one), 
                lambda: tf.zeros_like(one_number, dtype=tf.float32),
                lambda: tf.divide(pos_sample, one_number))

            #find negative sample
            neg_sample_index = tf.not_equal(query_label, select_label)
            tmp_neg_sample = tf.fill(query_label.shape, -np.inf)
            neg_sample = tf.where(neg_sample_index, l_queue, tmp_neg_sample, name='neg_sample')

            neg_sample_index = tf.cast(neg_sample_index, dtype=tf.int32)
            neg_number = tf.reduce_sum(neg_sample_index, axis=1)
            neg_min = tf.reduce_min(neg_number, axis=0)
            neg_sample, _ = tf.nn.top_k(neg_sample, neg_min)

            #calculate and return
            logits_con = tf.concat([one_sample, neg_sample], axis=-1)
            logits_con /= 0.5

            labels_con = tf.zeros(self.batch_size, dtype=tf.int64)
            kl_loss = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=logits_con, labels=labels_con)
            kl_loss = tf.reduce_mean(kl_loss, name='xentropy-loss')

            return (kl_loss, update_ops)
    
    def push_queue(self, queue, label_queue, queue_ptr, keys, labels):
        
        end_queue_ptr = queue_ptr + self.batch_size
        inds = tf.range(queue_ptr, end_queue_ptr, dtype=tf.int64)
        queue_ptr_update = tf.assign(queue_ptr, end_queue_ptr % self.queue_size)
        queue_update = tf.assign(queue, tf.scatter_update(queue, inds, keys))
        label_queue_update = tf.assign(label_queue, tf.scatter_update(label_queue, inds, labels)) 
        
        return tf.group(queue_update, label_queue_update, queue_ptr_update)
 
