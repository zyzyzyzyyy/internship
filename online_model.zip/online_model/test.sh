time=$(date "+%Y%m%d")
export BERT_BASE_DIR=./chinese_wwm_ext_L-12_H-768_A-12
#export BERT_BASE_DIR=./new_global_cls_56
export MODEL_OUR_DIR=./new_global_cls_56
export MODEL_SAVED=./saved_model_56_$time/
export DATE_DIR=./data

CUDA_VISIBLE_DEVICES=0,1 python run_classifier.py\
  --task_name=bot \
  --do_train=false \
  --do_eval=false \
  --do_predict=true \
  --do_export=false \
  --save_checkpoints_steps=1000 \
  --data_dir=$DATE_DIR \
  --vocab_file=$BERT_BASE_DIR/vocab.txt \
  --bert_config_file=$BERT_BASE_DIR/bert_config.json \
  --max_seq_length=60 \
  --train_batch_size=64 \
  --learning_rate=2e-5 \
  --num_train_epochs=8 \
  --output_dir=$MODEL_OUR_DIR \
  --export_dir=$MODEL_SAVED \
  --id2label_file=id2label.txt \
  --init_checkpoint=./new_global_cls_56/model.ckpt-5287 \
 

