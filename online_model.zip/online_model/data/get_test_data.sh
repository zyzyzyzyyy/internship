scp liuxiangfeng@172.18.171.160:/Users/liuxiangfeng/Desktop/personal/liuxiangfeng/test.tsv ./
